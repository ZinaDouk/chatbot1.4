document.getElementById('question').addEventListener('change', function () {
    var selectedValue = this.value;
    var texte = document.getElementById('reponse');
    if (selectedValue) {
        switch (selectedValue) {
            case 'question1':
                texte.value = "Full stack development refers to the practice of developing both the frontend (client-side) and backend (server-side) of a web applications.";
                break;
            case 'question2':
                texte.value = "HTML, which stands for HyperText Markup Language, is the standard markup language used to create and design web pages.";
                break;
            case 'question3':
                texte.value = "In the context of computer networking, a server and a client are two fundamental components that interact with each other to facilitate communication and data exchange over a network.";
                break;
            case 'question4':
                texte.value = "A chatbot, also known as a tchat bot, can be useful for a wide range of purposes across various industries and applications. Here are some common use cases: Customer Support, Information Retrieval, Education and Training, Healthcare, HR and Recruitment, Entertainment and Gaming.";
                break;
            case 'question5':
                texte.value = "Of course not, there are more efficient ways to design a dynamic, reactive, and smart tchat Bots. This one is only a beginner level.";
                break;
            case 'first':
                texte.value = "The answer will appear here...";
        }
    }
});
